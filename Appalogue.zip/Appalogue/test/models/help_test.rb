require 'test_helper'

class HelpTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
