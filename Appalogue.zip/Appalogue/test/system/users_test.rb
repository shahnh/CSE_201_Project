require "test_helper"
require "application_system_test_case"

class UsersTest < ApplicationSystemTestCase
	driven_by :selenium, using: :chrome
end
