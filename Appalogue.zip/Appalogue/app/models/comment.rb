class Comment < ApplicationRecord
  belongs_to :app
end
