class Help < ApplicationRecord
	
end
