module SearchesHelper
end
